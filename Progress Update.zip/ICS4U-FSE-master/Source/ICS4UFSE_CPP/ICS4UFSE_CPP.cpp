// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "ICS4UFSE_CPP.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ICS4UFSE_CPP, "ICS4UFSE_CPP" );
 