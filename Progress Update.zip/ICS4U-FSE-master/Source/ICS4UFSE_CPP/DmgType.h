// Copyright (c) 2020 David Hui and Kevin Zhang. ALL RIGHTS RESERVED.
#pragma once
#include "CoreMinimal.h"
UENUM()
enum DmgType {   DmgMelee, DmgFire, DmgLightning, DmgIce, DmgEarth, DmgFall, DmgDebug   };
